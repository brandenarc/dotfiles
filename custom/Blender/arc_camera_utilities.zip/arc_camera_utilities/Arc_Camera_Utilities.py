
bl_info = {
    "name": "Arc Camera Utilities",
    "author": "Branden Arc",
    "version": (4, 5, 0),
    "blender": (4, 5, 0),
    "description": "Utilities for Managing Camera Properties, Press 'Y' to cycle through cameras.",
    "category": "Object",
}

import bpy

# Global list to store keymaps
addon_keymaps = []

# Define a Property Group for the default settings
class ArcCameraDefaults(bpy.types.PropertyGroup):
    lens: bpy.props.FloatProperty(name="Focal Length", default=50)
    dof_use: bpy.props.BoolProperty(name="Use Depth of Field", default=True)
    dof_aperture_fstop: bpy.props.FloatProperty(name="F-Stop", default=1.8)
    dof_aperture_blades: bpy.props.IntProperty(name="Aperture Blades", default=11)
    dof_aperture_ratio: bpy.props.FloatProperty(name="Ratio", default=2)
    dof_focus_distance: bpy.props.FloatProperty(name="Focus Distance", default=5)
    dof_focus_object: bpy.props.StringProperty(name="Focus Object", default="Depth Of Field")

class CycleCamerasOperator(bpy.types.Operator):
    bl_idname = "camera.cycle_cameras"
    bl_label = "Cycle Cameras"
    bl_description = "Press to cycle through each camera in the scene"

    def execute(self, context):
        scene = context.scene
        cycle_hidden_cameras = scene.cycle_hidden_cameras
        auto_view_through = scene.auto_view_through_camera

        cameras = [obj for obj in scene.objects if obj.type == 'CAMERA' and obj.name in context.view_layer.objects]

        if not cameras:
            self.report({'INFO'}, "No cameras found.")
            return {'CANCELLED'}

        current_camera = scene.camera
        if current_camera in cameras:
            current_index = cameras.index(current_camera)
        else:
            current_index = -1

        next_index = (current_index + 1) % len(cameras)

        while True:
            next_camera = cameras[next_index]
            if cycle_hidden_cameras or (not next_camera.hide_get() and not next_camera.hide_viewport):
                break
            next_index = (next_index + 1) % len(cameras)

        # Store f-stop values before switching
        fstop_values = {cam.name: cam.data.dof.aperture_fstop for cam in cameras}

        scene.camera = next_camera
        if context.mode == 'OBJECT':
            bpy.ops.object.select_all(action='DESELECT')
            next_camera.select_set(True)
            context.view_layer.objects.active = next_camera

            if auto_view_through:
                for area in bpy.context.screen.areas:
                    if area.type == 'VIEW_3D':
                        for space in area.spaces:
                            if space.type == 'VIEW_3D':
                                space.region_3d.view_perspective = 'CAMERA'

        # Restore f-stop values after switching
        for cam in cameras:
            cam.data.dof.aperture_fstop = fstop_values[cam.name]

        return {'FINISHED'}

class OBJECT_OT_add_arc_camera(bpy.types.Operator):
    bl_idname = "object.add_arc_camera"
    bl_label = "Add Arc Camera"
    bl_description = "Create a camera from view with default settings applied"

    def execute(self, context):
        defaults = context.scene.arc_camera_defaults

        dof_object = bpy.data.objects.get(defaults.dof_focus_object)
        if not dof_object:
            dof_object = bpy.data.objects.new("Depth Of Field", None)
            dof_object.empty_display_type = 'CIRCLE'
            dof_object.empty_display_size = 0.5
            context.collection.objects.link(dof_object)
            dof_object.location = (0, 0, 0)

        camera_data = bpy.data.cameras.new(name="Arc Camera")
        camera_data.lens = defaults.lens
        camera_data.passepartout_alpha = 1

        camera_object = bpy.data.objects.new("Arc Camera", camera_data)
        context.collection.objects.link(camera_object)
        camera_object.matrix_world = context.space_data.region_3d.view_matrix.inverted()

        context.view_layer.objects.active = camera_object
        context.scene.camera = camera_object

        bpy.context.view_layer.objects.active = camera_object
        bpy.context.view_layer.update()

        camera_object.data.dof.use_dof = defaults.dof_use
        camera_object.data.dof.aperture_fstop = defaults.dof_aperture_fstop
        camera_object.data.dof.aperture_blades = defaults.dof_aperture_blades
        camera_object.data.dof.aperture_ratio = defaults.dof_aperture_ratio
        camera_object.data.dof.focus_distance = defaults.dof_focus_distance
        camera_object.data.dof.focus_object = dof_object

        bpy.ops.view3d.view_camera()
        return {'FINISHED'}

# Panels
class CYCLE_CAMERAS_PT_menu(bpy.types.Panel):
    bl_label = "Cycle Cameras"
    bl_idname = "CYCLE_CAMERAS_PT_menu"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Arc Camera'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        if scene.camera:
            layout.label(text=f"{scene.camera.name}", icon='CAMERA_DATA')
        layout.operator("camera.cycle_cameras")
        layout.prop(scene, "cycle_hidden_cameras")
        layout.prop(scene, "auto_view_through_camera")

class ADJUST_CAMERA_PT_menu(bpy.types.Panel):
    bl_label = "Adjust Current Camera"
    bl_idname = "ADJUST_CAMERA_PT_menu"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Arc Camera'

    def draw(self, context):
        layout = self.layout
        cam = context.scene.camera.data
        layout.label(text=f"{context.scene.camera.name}", icon='CAMERA_DATA')
        layout.prop(cam, "lens")
        layout.prop(cam.dof, "use_dof")
        if cam.dof.use_dof:
            layout.prop(cam.dof, "aperture_fstop")
            layout.prop(cam.dof, "aperture_blades")
            layout.prop(cam.dof, "aperture_ratio")

class FOCUS_SETTINGS_PT_menu(bpy.types.Panel):
    bl_label = "Focus Settings"
    bl_idname = "FOCUS_SETTINGS_PT_menu"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Arc Camera'

    def draw(self, context):
        layout = self.layout
        cam = context.scene.camera.data
        if cam.dof.use_dof:
            layout.prop_search(cam.dof, "focus_object", bpy.data, "objects")
            if not cam.dof.focus_object:
                layout.prop(cam.dof, "focus_distance")

class DEFAULT_CAMERA_PT_menu(bpy.types.Panel):
    bl_label = "Default Camera Settings"
    bl_idname = "DEFAULT_CAMERA_PT_menu"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Arc Camera'

    def draw(self, context):
        layout = self.layout
        defaults = context.scene.arc_camera_defaults
        layout.operator("object.add_arc_camera")
        layout.prop(defaults, "lens")
        layout.prop(defaults, "dof_use")
        if defaults.dof_use:
            layout.prop(defaults, "dof_aperture_fstop")
            layout.prop(defaults, "dof_aperture_blades")
            layout.prop(defaults, "dof_aperture_ratio")
            focus_box = layout.box()
            focus_box.label(text="Default Focus Settings")
            focus_box.prop_search(defaults, "dof_focus_object", bpy.data, "objects", text="Focus Object")
            if not bpy.data.objects.get(defaults.dof_focus_object):
                focus_box.prop(defaults, "dof_focus_distance")
            else:
                row = focus_box.row()
                row.enabled = False
                row.prop(defaults, "dof_focus_distance")

def add_arc_camera_button(self, context):
    self.layout.operator(OBJECT_OT_add_arc_camera.bl_idname, text="Arc Camera", icon='CAMERA_DATA')

def register():
    bpy.utils.register_class(ArcCameraDefaults)
    bpy.utils.register_class(CycleCamerasOperator)
    bpy.utils.register_class(OBJECT_OT_add_arc_camera)
    bpy.utils.register_class(CYCLE_CAMERAS_PT_menu)
    bpy.utils.register_class(ADJUST_CAMERA_PT_menu)
    bpy.utils.register_class(FOCUS_SETTINGS_PT_menu)
    bpy.utils.register_class(DEFAULT_CAMERA_PT_menu)
    bpy.types.Scene.arc_camera_defaults = bpy.props.PointerProperty(type=ArcCameraDefaults)
    bpy.types.Scene.cycle_hidden_cameras = bpy.props.BoolProperty(name="Include Hidden Cameras", default=False)
    bpy.types.Scene.auto_view_through_camera = bpy.props.BoolProperty(name="Auto View Through Camera", default=False)
    bpy.types.VIEW3D_MT_add.append(add_arc_camera_button)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new(CycleCamerasOperator.bl_idname, type='Y', value='PRESS')
        addon_keymaps.append((km, kmi))

def unregister():
    bpy.types.VIEW3D_MT_add.remove(add_arc_camera_button)
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(CycleCamerasOperator)
    bpy.utils.unregister_class(OBJECT_OT_add_arc_camera)
    bpy.utils.unregister_class(CYCLE_CAMERAS_PT_menu)
    bpy.utils.unregister_class(ADJUST_CAMERA_PT_menu)
    bpy.utils.unregister_class(FOCUS_SETTINGS_PT_menu)
    bpy.utils.unregister_class(DEFAULT_CAMERA_PT_menu)
    del bpy.types.Scene.arc_camera_defaults
    del bpy.types.Scene.cycle_hidden_cameras
    del bpy.types.Scene.auto_view_through_camera
    bpy.utils.unregister_class(ArcCameraDefaults)

if __name__ == "__main__":
    register()
