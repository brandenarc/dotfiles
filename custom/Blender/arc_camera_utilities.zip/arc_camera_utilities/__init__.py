
bl_info = {
    "name": "Arc Camera Utilities",
    "author": "Branden Arc",
    "version": (4, 5, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Arc Camera",
    "description": "Utilities for Managing Camera Properties, Press 'Y' to cycle through cameras.",
    "category": "Object",
}

from .Arc_Camera_Utilities import register, unregister

if __name__ == "__main__":
    register()
